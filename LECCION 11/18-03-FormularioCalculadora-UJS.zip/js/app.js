console.log('Aplicación Calculadora');

